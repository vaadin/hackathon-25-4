package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.NativeButton;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.signals.Signal;
import com.vaadin.flow.signals.shared.SharedValueSignal;

/**
 * Binds a text to a shared signal in the constructor, and then, before the
 * view is attached, changes the signal: on another thread for /?by=other, on
 * this one for /?by=same. Either way the change is over before the attach.
 */
@Route("")
public class ChangedBeforeAttachView extends Div implements BeforeEnterObserver {

    private final SharedValueSignal<String> signal = new SharedValueSignal<>("initial");
    private final Span bound = new Span();
    private final Paragraph log = new Paragraph();

    public ChangedBeforeAttachView() {
        bound.setId("bound");
        bound.bindText(signal);
        Signal.effect(this, () -> System.out.println("REPRO the effect ran with " + signal.get()));
        log.setId("log");
        var later = new Paragraph();
        later.setId("later");
        var ask = new NativeButton("Ask again", click -> {
            later.setText("a round trip later: peek()=" + signal.peek() + ", the bound text is " + bound.getText());
            System.out.println("REPRO " + later.getText());
        });
        ask.setId("ask");
        add(bound, log, ask, later);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String by = event.getLocation().getQueryParameters().getSingleParameter("by").orElse("other");
        if (by.equals("same")) {
            signal.set("changed");
        } else {
            Thread other = Thread.ofPlatform().start(() -> signal.set("changed"));
            try {
                other.join();
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
            }
        }
        log.setText("changed by the " + by + " thread before attach, attached=" + isAttached() + ", peek()="
                + signal.peek());
        System.out.println("REPRO " + log.getText());
    }
}
