// Any module of the application's own makes the build create an application bundle.
window.hello = 'hello';
