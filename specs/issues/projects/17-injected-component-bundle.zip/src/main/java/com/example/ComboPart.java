package com.example;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.spring.annotation.SpringComponent;

/** The implementation, found by Spring. No route names this class. */
@SpringComponent
class ComboPart implements Part {

    @Override
    public Component create() {
        var combo = new ComboBox<String>("Version");
        combo.setItems("25.3.5", "24.9.21");
        return combo;
    }
}
