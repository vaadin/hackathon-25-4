package com.example;

import com.vaadin.flow.component.Component;

/** What a layout or view asks for, without naming the implementation. */
public interface Part {
    Component create();
}
