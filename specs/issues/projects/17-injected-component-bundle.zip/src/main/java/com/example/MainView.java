package com.example;

import com.vaadin.flow.component.dependency.JsModule;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.Route;

@Route("")
@JsModule("./hello.js")
public class MainView extends Div {

    public MainView(Part part) {
        add(part.create());
    }
}
