package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.NativeButton;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.signals.Signal;

/**
 * A paragraph bound to the request counter through an element effect, and a
 * button whose click is a request of this UI.
 */
@Route("")
public class MainView extends Div {

    public MainView() {
        var count = new Paragraph();
        count.setId("count");
        Signal.effect(count, () -> count.setText("requests ended: " + RequestCounter.ENDED.get()));
        var clicked = new Paragraph("not clicked");
        clicked.setId("clicked");
        var click = new NativeButton("Click", event -> clicked.setText("clicked"));
        click.setId("click");
        add(count, click, clicked);
    }
}
