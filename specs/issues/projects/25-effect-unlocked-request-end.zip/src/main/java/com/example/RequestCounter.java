package com.example;

import org.springframework.stereotype.Component;

import com.vaadin.flow.server.RequestEndedEvent;
import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.VaadinServiceInitListener;
import com.vaadin.flow.signals.shared.SharedValueSignal;

/** Counts the requests that end, in a signal every UI can bind to. */
@Component
public class RequestCounter implements VaadinServiceInitListener {

    static final SharedValueSignal<Integer> ENDED = new SharedValueSignal<>(0);

    @Override
    public void serviceInit(ServiceInitEvent event) {
        event.getSource().getEventBus().addListener(RequestEndedEvent.class,
                ended -> ENDED.update(count -> count + 1));
    }
}
