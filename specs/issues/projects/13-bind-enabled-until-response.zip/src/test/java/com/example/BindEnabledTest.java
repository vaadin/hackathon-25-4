package com.example;

import org.junit.jupiter.api.Test;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.shared.DisableOnClickMode;
import com.vaadin.flow.signals.local.ValueSignal;

/**
 * A Check button: disabled while the question is empty, and disabled on click
 * until the response, so a slow answer cannot be asked twice.
 */
class BindEnabledTest {

    @Test
    void until_response_then_bind_enabled() {
        var asked = new ValueSignal<>(false);
        var check = new Button("Check");
        check.setDisableOnClick(DisableOnClickMode.UNTIL_RESPONSE);
        report("setDisableOnClick(UNTIL_RESPONSE), then bindEnabled", () -> check.bindEnabled(asked));
    }

    @Test
    void bind_enabled_then_until_response() {
        var asked = new ValueSignal<>(false);
        var check = new Button("Check");
        check.bindEnabled(asked);
        report("bindEnabled, then setDisableOnClick(UNTIL_RESPONSE)",
                () -> check.setDisableOnClick(DisableOnClickMode.UNTIL_RESPONSE));
    }

    @Test
    void until_response_then_set_enabled() {
        var check = new Button("Check");
        check.setDisableOnClick(DisableOnClickMode.UNTIL_RESPONSE);
        report("setDisableOnClick(UNTIL_RESPONSE), then setEnabled(false)", () -> check.setEnabled(false));
    }

    private static void report(String what, Runnable call) {
        try {
            call.run();
            System.out.println("RESULT " + what + ": accepted");
        } catch (RuntimeException refused) {
            System.out.println("RESULT " + what + ": " + refused.getClass().getSimpleName() + ": "
                    + refused.getMessage());
        }
    }
}
