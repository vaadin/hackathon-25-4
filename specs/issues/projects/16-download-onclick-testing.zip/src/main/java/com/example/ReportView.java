package com.example;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.download.Download;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.streams.DownloadHandler;
import com.vaadin.flow.server.streams.DownloadResponse;

/** The same file offered twice: by a link, and by a button through Download.onClick. */
@Route("")
public class ReportView extends VerticalLayout {

    static final String CSV = "advisory,bucket\nCVE-2026-89407,fix_available\n";

    public ReportView() {
        var link = new Anchor(handler(), "Download as a link");
        link.setId("link");
        var button = new Button("Download as a button");
        button.setId("button");
        Download.onClick(button, handler());
        add(link, button);
    }

    private static DownloadHandler handler() {
        return DownloadHandler.fromInputStream(event -> {
            byte[] bytes = CSV.getBytes(StandardCharsets.UTF_8);
            return new DownloadResponse(new ByteArrayInputStream(bytes), "triage.csv", "text/csv", bytes.length);
        }, "triage.csv");
    }
}
