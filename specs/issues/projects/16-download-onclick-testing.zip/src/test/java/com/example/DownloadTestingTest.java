package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.vaadin.browserless.SpringBrowserlessTest;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonTester;
import com.vaadin.flow.component.html.Anchor;

@SpringBootTest
class DownloadTestingTest extends SpringBrowserlessTest {

    @Test
    void the_file_a_button_downloads_can_be_fetched_in_a_test_as_the_links_can() {
        navigate(ReportView.class);

        // The link: the tester fetches what the handler serves.
        var out = new ByteArrayOutputStream();
        test(find(Anchor.class).id("link")).download(out);
        String fromLink = out.toString(StandardCharsets.UTF_8);
        System.out.println("AnchorTester.download: " + fromLink.length() + " bytes");
        assertEquals(ReportView.CSV, fromLink);

        // The button: no tester method, and nothing on its element names the address.
        Button button = find(Button.class).id("button");
        String testerMethods = Arrays.stream(ButtonTester.class.getMethods()).map(Method::getName)
                .filter(name -> name.toLowerCase().contains("download")).collect(Collectors.joining(", "));
        String attributes = button.getElement().getAttributeNames()
                .map(name -> name + "=" + button.getElement().getAttribute(name)).collect(Collectors.joining(", "));
        String properties = button.getElement().getPropertyNames().collect(Collectors.joining(", "));
        System.out.println("ButtonTester methods about downloads: [" + testerMethods + "]");
        System.out.println("Button attributes: [" + attributes + "], properties: [" + properties + "]");
        assertTrue(!testerMethods.isEmpty() || attributes.contains("href") || properties.contains("href"),
                "the file Download.onClick serves cannot be fetched from a test");
    }
}
