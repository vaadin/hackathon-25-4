package com.example;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.Route;

/** A grid whose rows open a details component on click, the default. */
@Route("")
public class PeopleView extends VerticalLayout {

    final Grid<String> grid = new Grid<>();

    public PeopleView() {
        grid.addColumn(name -> name).setHeader("Name");
        grid.setItemDetailsRenderer(new ComponentRenderer<>(name -> new Span("Details of " + name)));
        grid.setItems("Ada", "Grace");
        add(grid);
    }
}
