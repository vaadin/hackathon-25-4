package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.vaadin.browserless.SpringBrowserlessTest;
import com.vaadin.flow.component.html.Span;

@SpringBootTest
class ItemDetailsTesterTest extends SpringBrowserlessTest {

    @Test
    void clicking_a_row_opens_its_details() {
        var view = navigate(PeopleView.class);
        var grid = test(view.grid);

        grid.clickRow(0);

        boolean visible = view.grid.isDetailsVisible(grid.getRow(0));
        System.out.println("details visible after clickRow(0): " + visible);
        assertTrue(visible);
    }

    @Test
    void opened_details_can_be_read() {
        var view = navigate(PeopleView.class);
        view.grid.setDetailsVisible("Ada", true);

        int found = $(Span.class).withText("Details of Ada").all().size();
        System.out.println("details visible after setDetailsVisible: " + view.grid.isDetailsVisible("Ada"));
        System.out.println("Span \"Details of Ada\" found by a query: " + found);
        // No GridTester method returns the details component either.
        assertEquals(1, found);
    }
}
