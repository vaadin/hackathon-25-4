package com.example;

import java.util.List;

import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.signals.local.ValueSignal;

/**
 * A version field that shows what the reader typed last time, kept in a
 * signal, and offers the known versions. The two routes differ only in the
 * order of bindValue and setItems.
 */
abstract class VersionField extends Div {

    static final List<String> KNOWN = List.of("25.3.5", "24.9.21");

    final ComboBox<String> version = new ComboBox<>();
    final ValueSignal<String> remembered = new ValueSignal<>("24.9.21");

    VersionField(boolean bindFirst) {
        version.setAllowCustomValue(true);
        if (bindFirst) {
            version.bindValue(remembered, remembered::set);
            version.setItems(KNOWN);
        } else {
            version.setItems(KNOWN);
            version.bindValue(remembered, remembered::set);
        }
        add(version);
    }
}
