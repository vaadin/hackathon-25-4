package com.example;

import com.vaadin.flow.router.Route;

@Route("items-first")
public class ItemsFirstView extends VersionField {

    public ItemsFirstView() {
        super(false);
    }
}
