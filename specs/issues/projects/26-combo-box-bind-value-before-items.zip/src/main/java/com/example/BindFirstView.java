package com.example;

import com.vaadin.flow.router.Route;

@Route("bind-first")
public class BindFirstView extends VersionField {

    public BindFirstView() {
        super(true);
    }
}
