package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.vaadin.browserless.SpringBrowserlessTest;

@SpringBootTest
class BindValueBeforeItemsTest extends SpringBrowserlessTest {

    @Test
    void set_items_then_bind_value() {
        var view = navigate(ItemsFirstView.class);
        System.out.println("REPRO setItems, then bindValue: value " + view.version.getValue());
    }

    @Test
    void bind_value_then_set_items() {
        try {
            var view = navigate(BindFirstView.class);
            System.out.println("REPRO bindValue, then setItems: value " + view.version.getValue());
        } catch (RuntimeException failure) {
            Throwable cause = failure;
            while (cause.getCause() != null) {
                cause = cause.getCause();
            }
            System.out.println("REPRO bindValue, then setItems: " + cause);
        }
    }
}
