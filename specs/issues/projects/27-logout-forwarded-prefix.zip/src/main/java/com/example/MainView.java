package com.example;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.security.AuthenticationContext;
import jakarta.annotation.security.PermitAll;

@Route("")
@PermitAll
public class MainView extends VerticalLayout {

    public MainView(AuthenticationContext authentication) {
        add(new Paragraph("Signed in. Sign out should open http://localhost:8128/app/login."),
                new Button("Sign out", click -> authentication.logout()));
    }
}
