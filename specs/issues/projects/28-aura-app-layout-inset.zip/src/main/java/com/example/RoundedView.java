package com.example;

import com.vaadin.flow.router.Route;

/** The same layout with the inset rounded to a whole pixel, as Aura rounds its padding tokens. */
@Route("rounded")
public class RoundedView extends InsetView {

    public RoundedView() {
        addClassName("rounded");
    }
}
