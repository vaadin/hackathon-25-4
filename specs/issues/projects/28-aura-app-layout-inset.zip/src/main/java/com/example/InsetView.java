package com.example;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.SvgIcon;
import com.vaadin.flow.router.Route;

/**
 * An app layout whose drawer holds a 32 pixel icon. The page measures itself:
 * the drawer's inline padding and the icon's x. With Aura as shipped both land
 * on fractions of a pixel whenever 1.5vmin is not whole.
 */
@Route("")
public class InsetView extends AppLayout {

    private final Paragraph measured = new Paragraph();

    public InsetView() {
        var icon = new SvgIcon("icons/mark.svg");
        icon.getStyle().set("--vaadin-icon-size", "32px").set("--vaadin-icon-visual-size", "100%");
        var brand = new Div(icon, new Span("Brand"));
        brand.getStyle().set("display", "flex").set("align-items", "center").set("gap", "8px").set("padding", "12px 16px");
        addToDrawer(brand);
        addToNavbar(new Span("Aura app layout inset"));
        setContent(new Div(measured, new Button("Measure again", click -> measure())));
        addAttachListener(attach -> measure());
    }

    private void measure() {
        getElement().executeJs("""
                return new Promise(done => requestAnimationFrame(() => requestAnimationFrame(() => {
                  const drawer = this.shadowRoot.querySelector('[part~="drawer"]');
                  const icon = document.querySelector('vaadin-icon');
                  done('window ' + innerWidth + 'x' + innerHeight
                    + ', 1.5vmin = ' + (Math.min(innerWidth, innerHeight) * 0.015) + 'px'
                    + ', drawer padding-inline-start = ' + getComputedStyle(drawer).paddingInlineStart
                    + ', icon x = ' + icon.getBoundingClientRect().x);
                })))""").then(String.class, measured::setText);
    }
}
