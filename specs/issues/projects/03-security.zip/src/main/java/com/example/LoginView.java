package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.login.LoginForm;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

@Route("login")
@AnonymousAllowed
public class LoginView extends Div {

    public LoginView() {
        var form = new LoginForm();
        form.setAction("login");
        add(form);
    }
}
