package com.example;

import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

/** A public page. The h1 is styled by the declared sheet, the h2 by the sheet it imports. */
@Route("")
@AnonymousAllowed
public class PublicView extends Div {

    public PublicView() {
        add(new H1("Green, from styles/main.css"), new H2("Red, from the imported styles/parts.css"),
                new Div(new Anchor("admin", "The admin view")), new Div(new Anchor("missing", "An address that matches no route")));
    }
}
