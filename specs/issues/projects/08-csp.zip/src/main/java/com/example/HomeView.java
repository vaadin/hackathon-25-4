package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.router.Route;

@Route("")
public class HomeView extends Div {

    public HomeView() {
        add(new Paragraph("vaadin.csp=strict is set in application.properties. Read the response headers."));
    }
}
