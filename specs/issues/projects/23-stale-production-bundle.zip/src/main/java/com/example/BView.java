package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.router.Route;

/**
 * The route added after the first production build. It uses only HTML
 * elements, so it brings no import the bundle lacks, and the build reuses the
 * bundle.
 */
@Route(value = "b", layout = MainLayout.class)
public class BView extends Div {

    public BView() {
        add(new Paragraph("Route B, added after the first production build."));
    }
}
