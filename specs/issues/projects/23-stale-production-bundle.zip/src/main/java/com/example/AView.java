package com.example;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.Route;

/** The route the first production build knows. */
@Route(value = "a", layout = MainLayout.class)
public class AView extends Div {

    public AView() {
        add(new Button("A button"));
    }
}
