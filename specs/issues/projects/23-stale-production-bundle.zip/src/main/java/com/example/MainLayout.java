package com.example;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;

/** The shell both routes use. Its web components are what goes missing on /b. */
public class MainLayout extends AppLayout {

    public MainLayout() {
        addToNavbar(new DrawerToggle());
        var nav = new SideNav();
        nav.addItem(new SideNavItem("A", "a"), new SideNavItem("B", "b"));
        addToDrawer(nav);
    }
}
