package com.example;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.component.page.ColorScheme;
import com.vaadin.flow.component.page.WebStorage;
import com.vaadin.flow.router.Route;

/** Remembers a dark choice in web storage and applies it the only way the server can: after attach. */
@Route("")
public class SchemeView extends Div {

    private static final String KEY = "scheme";

    public SchemeView() {
        var report = new Pre();
        report.setId("report");

        add(new Button("Remember dark", click -> {
            WebStorage.setItem(KEY, "dark");
            UI.getCurrent().getPage().setColorScheme(ColorScheme.Value.DARK);
        }), new Button("Forget", click -> {
            WebStorage.removeItem(KEY);
            UI.getCurrent().getPage().setColorScheme(ColorScheme.Value.LIGHT_DARK);
        }), new Button("Measure", click -> measure(report)), report);

        addAttachListener(attach -> WebStorage.getItem(attach.getUI(), WebStorage.Storage.LOCAL_STORAGE, KEY)
                .thenAccept(remembered -> {
                    if ("dark".equals(remembered)) {
                        attach.getUI().getPage().setColorScheme(ColorScheme.Value.DARK);
                    }
                }));
    }

    private void measure(Pre report) {
        var page = UI.getCurrent().getPage();
        page.retrieveExtendedClientDetails(details -> page.executeJs("""
                return 'first frame text color: ' + window.firstFrame
                    + '\\ncurrent text color:     ' + getComputedStyle(document.documentElement).color
                    + '\\nsystem prefers dark:    ' + window.matchMedia('(prefers-color-scheme: dark)').matches
                """).then(String.class, browser -> report.setText(browser
                        + "\nExtendedClientDetails.getColorScheme(): " + details.getColorScheme()
                        + "\nPage.getColorScheme():                  " + page.getColorScheme())));
    }
}
