package com.example;

import static org.junit.jupiter.api.Assertions.assertFalse;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.junit.jupiter.api.Test;

import com.vaadin.flow.component.clipboard.ClipboardBinding;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.function.SerializableConsumer;
// The only way to name the type of the error callback:
import com.vaadin.flow.component.trigger.internal.PromiseAction;

class ClipboardErrorTypeTest {

    /** One error handler shared by every copy button of an application, which has to name the type. */
    static final SerializableConsumer<PromiseAction.Error> SAY_IT_FAILED = error -> Notification
            .show("Could not copy: " + error.name());

    @Test
    void the_error_type_of_the_observed_clipboard_write_is_public_api() throws Exception {
        Method writeText = ClipboardBinding.class.getMethod("writeText", String.class, SerializableConsumer.class,
                SerializableConsumer.class);
        Type onError = writeText.getGenericParameterTypes()[2];
        Type error = ((ParameterizedType) onError).getActualTypeArguments()[0];
        String name = ((Class<?>) error).getName();
        System.out.println("ClipboardBinding.writeText(String, onCopied, onError): onError accepts " + name);
        assertFalse(((Class<?>) error).getPackageName().endsWith(".internal"),
                "a public method takes a type from an internal package: " + name);
    }
}
