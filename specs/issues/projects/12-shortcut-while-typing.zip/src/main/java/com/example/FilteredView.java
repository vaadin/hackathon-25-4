package com.example;

import java.io.Serializable;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.dom.DomEventFilter;
import com.vaadin.flow.js.JsDefinition;
import com.vaadin.flow.js.JsExpression;
import com.vaadin.flow.js.JsSnippets;
import com.vaadin.flow.router.Route;

/** The same slash, through a DOM listener with a declared filter. */
@Route("filtered")
public class FilteredView extends Div {

    @JsDefinition
    public interface SlashJs extends Serializable {

        @JsExpression("return event.key === '/' && !event.composedPath().some(node => node instanceof HTMLElement && (node.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(node.tagName)))")
        DomEventFilter slashOutsideAField();
    }

    public FilteredView() {
        var note = new TextField("Note");
        note.setId("note");
        var search = new TextField("Search");
        search.setId("search");
        add(new Paragraph("Slash focuses Search. Type a/b into Note."), note, search);
        UI.getCurrent().getElement().addEventListener("keydown", event -> search.focus())
                .setFilterExpression(JsSnippets.of(SlashJs.class).slashOutsideAField()).preventDefault();
    }
}
