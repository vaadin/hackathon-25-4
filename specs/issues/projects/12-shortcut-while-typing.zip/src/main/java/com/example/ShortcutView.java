package com.example;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;

/** The slash as a shortcut, through the shortcut API. */
@Route("")
public class ShortcutView extends Div {

    public ShortcutView() {
        var note = new TextField("Note");
        note.setId("note");
        var search = new TextField("Search");
        search.setId("search");
        add(new Paragraph("Slash focuses Search. Type a/b into Note."), note, search);
        UI.getCurrent().addShortcutListener(() -> search.focus(), Key.of("/"));
    }
}
