package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.QueryParameters;

class QueryParametersOrderTest {

    private static final String ASKED = "boot=1&ruled=1&disc=1&open=x";

    @Test
    void a_query_string_read_and_written_back_keeps_its_order() {
        String written = QueryParameters.fromString(ASKED).getQueryString();
        System.out.println("fromString(\"" + ASKED + "\").getQueryString() = " + written);
        assertEquals(ASKED, written);
    }

    @Test
    void parameters_built_in_order_keep_it() {
        Map<String, List<String>> built = new LinkedHashMap<>();
        built.put("boot", List.of("1"));
        built.put("ruled", List.of("1"));
        built.put("disc", List.of("1"));
        built.put("open", List.of("x"));
        String written = new QueryParameters(built).getQueryString();
        System.out.println("new QueryParameters(LinkedHashMap boot, ruled, disc, open).getQueryString() = " + written);
        assertEquals(ASKED, written);
    }

    @Test
    void a_location_parsed_from_an_address_keeps_its_order() {
        String address = "version/24.9.21?" + ASKED;
        String written = new Location(address).getPathWithQueryParameters();
        System.out.println("new Location(\"" + address + "\").getPathWithQueryParameters() = " + written);
        assertEquals(address, written);
    }
}
