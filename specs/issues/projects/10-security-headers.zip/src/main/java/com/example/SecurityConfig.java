package com.example;

import com.vaadin.flow.spring.security.VaadinSecurityConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/** The documented Vaadin setup, plus one header asked of Spring Security. */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.headers(headers -> headers
                .contentSecurityPolicy(policy -> policy.policyDirectives("frame-ancestors 'none'")));
        return http.with(VaadinSecurityConfigurer.vaadin(), vaadin -> {
        }).build();
    }
}
