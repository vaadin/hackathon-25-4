package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

@Route("")
@AnonymousAllowed
public class HomeView extends Div {

    public HomeView() {
        add(new Paragraph("Read the response headers of this page: curl -s -D - -o /dev/null localhost:8110/"));
    }
}
