package com.example;

import com.vaadin.flow.component.breadcrumbs.Breadcrumbs;
import com.vaadin.flow.component.breadcrumbs.BreadcrumbsItem;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Pre;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;

@Route("")
@PageTitle("Orders")
public class OrdersView extends Div {

    public OrdersView() {
        add(trailWithBrandLink(), new RouterLink("Order details", OrderDetailsView.class));
    }

    /** The router's trail, with one fixed item in front that is not a route. */
    static Div trailWithBrandLink() {
        var breadcrumbs = new Breadcrumbs();
        var outcome = new Pre();
        outcome.setId("outcome");
        try {
            breadcrumbs.addComponentAsFirst(new BreadcrumbsItem("Example Corp", "https://example.com"));
            outcome.setText("accepted");
        } catch (RuntimeException refused) {
            outcome.setText(refused.getClass().getSimpleName() + ": " + refused.getMessage());
        }
        return new Div(breadcrumbs, outcome);
    }
}
