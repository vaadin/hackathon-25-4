package com.example;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteParent;

@Route("details")
@RouteParent(OrdersView.class)
@PageTitle("Order details")
public class OrderDetailsView extends Div {

    public OrderDetailsView() {
        add(OrdersView.trailWithBrandLink());
    }
}
