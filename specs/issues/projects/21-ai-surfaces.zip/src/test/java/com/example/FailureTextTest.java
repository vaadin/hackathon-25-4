package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Locale;

import org.junit.jupiter.api.Test;

import com.vaadin.browserless.BrowserlessConfiguration;
import com.vaadin.browserless.BrowserlessUIContext;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.ai.provider.ToolCallLimitExceededException;

/**
 * A failed turn writes a fixed English sentence into the message list, whatever
 * the locale and the names the application gave, and the 25.4 limit exception
 * carries what was exceeded only inside its message.
 */
class FailureTextTest {

    @Test
    void a_failed_turn_says_a_fixed_english_sentence() {
        var configuration = BrowserlessConfiguration.builder().withFeatureFlags("aiComponents").build();
        var window = BrowserlessUIContext.forComponent(configuration, Chat::new);
        UI.getCurrent().setLocale(Locale.of("fi", "FI"));

        window.findMessageInput().send("Montako?");

        var messages = window.findMessageList().getMessages();
        messages.forEach(item -> System.out.println(item.getUserName() + ": " + item.getText()));
        assertEquals("An error occurred. Please try again.", messages.getLast().getText());

        Chat chat = (Chat) window.find(Chat.class).single();
        System.out.println("reported: " + chat.reported);
        System.out.println("public methods of the exception beyond Throwable: " + java.util.Arrays
                .stream(ToolCallLimitExceededException.class.getDeclaredMethods()).map(m -> m.getName()).toList());
        window.close();
    }
}
