package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.vaadin.flow.component.ai.grid.AIDataRow;
import com.vaadin.flow.component.ai.grid.GridAIController;
import com.vaadin.flow.component.ai.grid.GridState;
import com.vaadin.flow.component.grid.Grid;

/**
 * The controller takes only a Grid of its own row type and replaces whatever
 * the application configured on it: a typed grid with its own columns cannot
 * be narrowed by it, only rebuilt.
 */
class GridControllerTest {

    record Person(String name, String team) {
    }

    @Test
    void the_controller_replaces_the_columns_the_application_set() {
        // What an application has: a typed grid. This does not compile:
        // new GridAIController(new Grid<Person>(), new PeopleProvider());
        Grid<Person> typed = new Grid<>();
        typed.addColumn(Person::name).setHeader("Name").setKey("name");
        typed.addColumn(Person::team).setHeader("Team").setKey("team");
        System.out.println("typed grid columns: " + keys(typed));

        // The nearest the controller accepts: a Grid<AIDataRow>, configured by the application.
        Grid<AIDataRow> grid = new Grid<>();
        grid.addColumn(row -> "a column of the application").setKey("mine").setHeader("Mine");
        System.out.println("before: " + keys(grid));

        var controller = new GridAIController(grid, new PeopleProvider());
        controller.restoreState(new GridState("SELECT name AS \"Name\", team AS \"Team\" FROM people"));

        System.out.println("after:  " + keys(grid));
        assertEquals(false, keys(grid).contains("mine"), "the application's column survived");
    }

    private static List<String> keys(Grid<?> grid) {
        return grid.getColumns().stream().map(column -> column.getKey() + "/" + column.getHeaderText()).toList();
    }
}
