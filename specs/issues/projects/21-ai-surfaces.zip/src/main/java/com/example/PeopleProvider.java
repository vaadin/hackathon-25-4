package com.example;

import java.util.List;
import java.util.Map;

import com.vaadin.flow.component.ai.provider.DatabaseProvider;

/** A database of three people, answered without SQL: every query returns the same rows. */
public class PeopleProvider implements DatabaseProvider {

    @Override
    public String getSchema() {
        return "people(name VARCHAR, team VARCHAR)";
    }

    @Override
    public List<Map<String, Object>> executeQuery(String sql) {
        if (sql.startsWith("SELECT COUNT(*)")) {
            return List.of(Map.of("c", 1));
        }
        return List.of(Map.of("Name", "Ada", "Team", "Core"));
    }
}
