package com.example;


import com.vaadin.flow.component.ai.orchestrator.AIOrchestrator;
import com.vaadin.flow.component.ai.provider.LLMProvider;
import com.vaadin.flow.component.ai.provider.ToolCallLimitExceededException;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.messages.MessageInput;
import com.vaadin.flow.component.messages.MessageList;

import reactor.core.publisher.Flux;

/** A chat in Finnish whose model stops at the tool call limit. */
public class Chat extends Div {

    public final MessageList list = new MessageList();
    public final MessageInput input = new MessageInput();
    public volatile Throwable reported;

    public Chat() {
        LLMProvider limited = request -> Flux.error(
                new ToolCallLimitExceededException("Tool call limit exceeded: lookup was called 41 times"));
        AIOrchestrator.builder(limited, "Vastaa suomeksi.")
                .withMessageList(list)
                .withInput(input)
                .withUserName("Sinä")
                .withAssistantName("Avustaja")
                .withResponseListener(event -> event.getError().ifPresent(error -> reported = error))
                .build();
        add(list, input);
    }
}
