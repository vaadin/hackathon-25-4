package com.example;

import java.util.List;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.contextmenu.GridContextMenu;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

/** Two grids with the same context menu: one through the 25.4 provider, one through the deprecated handler. */
@Route("")
public class PeopleView extends VerticalLayout {

    final Grid<String> withProvider = new Grid<>();
    final Grid<String> withHandler = new Grid<>();

    public PeopleView() {
        for (Grid<String> grid : List.of(withProvider, withHandler)) {
            grid.addColumn(name -> name).setHeader("Name").setKey("name");
            grid.setItems("Ada", "Grace");
        }

        var provided = new GridContextMenu<>(withProvider);
        provided.setDynamicContentProvider(context -> {
            if (context.item() == null) {
                return false;
            }
            provided.removeAll();
            provided.addItem("Email " + context.item());
            return true;
        });

        var handled = new GridContextMenu<>(withHandler);
        handled.setDynamicContentHandler(name -> {
            if (name == null) {
                return false;
            }
            handled.removeAll();
            handled.addItem("Email " + name);
            return true;
        });

        add(withProvider, withHandler);
    }
}
