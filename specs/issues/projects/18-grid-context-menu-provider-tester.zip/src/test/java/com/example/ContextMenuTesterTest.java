package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.vaadin.browserless.SpringBrowserlessTest;

@SpringBootTest
class ContextMenuTesterTest extends SpringBrowserlessTest {

    @Test
    void deprecated_handler_opens() {
        var view = navigate(PeopleView.class);
        var menu = test(view.withHandler).contextMenu(0);
        menu.open();
        System.out.println("setDynamicContentHandler: " + menu.getItemTexts());
        assertEquals(List.of("Email Ada"), menu.getItemTexts());
    }

    @Test
    void provider_opens() {
        var view = navigate(PeopleView.class);
        var menu = test(view.withProvider).contextMenu(0);
        try {
            menu.open();
        } catch (RuntimeException failure) {
            System.out.println("setDynamicContentProvider: " + failure);
            throw failure;
        }
        System.out.println("setDynamicContentProvider: " + menu.getItemTexts());
        assertEquals(List.of("Email Ada"), menu.getItemTexts());
    }
}
